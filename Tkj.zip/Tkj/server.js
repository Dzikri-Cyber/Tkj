const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const path = require('path');
const fs = require('fs');
const dotenv = require('dotenv');
const sqlite3 = require('sqlite3');
const { open } = require('sqlite');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');

dotenv.config();

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

// ============ MIDDLEWARE ============
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(express.static('public'));
app.use('/uploads', express.static('uploads'));

// ============ DATABASE ============
let db;

async function initDB() {
    // Buat folder uploads
    if (!fs.existsSync('./uploads')) fs.mkdirSync('./uploads');
    if (!fs.existsSync('./uploads/chat')) fs.mkdirSync('./uploads/chat');
    if (!fs.existsSync('./uploads/profiles')) fs.mkdirSync('./uploads/profiles');

    db = await open({
        filename: './database.sqlite',
        driver: sqlite3.Database
    });

    await db.exec(`
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT DEFAULT 'user',
            bio TEXT,
            profile_pic TEXT,
            status TEXT DEFAULT 'pending',
            max_devices INTEGER DEFAULT 2,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS devices (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            device_id TEXT UNIQUE,
            device_name TEXT,
            last_login TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            username TEXT,
            content TEXT,
            file_url TEXT,
            file_type TEXT,
            file_name TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT
        );
    `);

    // Buat admin pertama
    const adminEmail = process.env.ADMIN_EMAIL;
    const existing = await db.get('SELECT * FROM users WHERE email = ?', adminEmail);
    if (!existing) {
        const hashed = await bcrypt.hash(process.env.ADMIN_PASSWORD, 10);
        await db.run(`
            INSERT INTO users (username, email, password, role, status, bio)
            VALUES (?, ?, ?, ?, ?, ?)
        `, process.env.ADMIN_USERNAME, adminEmail, hashed, 'admin', 'approved', 'Administrator TJKT Hub');
        console.log(`✅ Admin dibuat: ${adminEmail} / ${process.env.ADMIN_PASSWORD}`);
    }

    // Settings default
    await db.run(`INSERT OR IGNORE INTO settings (key, value) VALUES ('max_devices_default', ?)`, process.env.MAX_DEVICES_DEFAULT);
    await db.run(`INSERT OR IGNORE INTO settings (key, value) VALUES ('registration_open', 'true')`);

    console.log('✅ Database siap');
}

// ============ MULTER (FILE UPLOAD) ============
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const dir = file.fieldname === 'profile' ? './uploads/profiles' : './uploads/chat';
        cb(null, dir);
    },
    filename: (req, file, cb) => {
        const ext = path.extname(file.originalname);
        cb(null, `${Date.now()}_${Math.random().toString(36).substr(2, 9)}${ext}`);
    }
});

const upload = multer({
    storage,
    limits: { fileSize: 20 * 1024 * 1024 }, // 20MB
    fileFilter: (req, file, cb) => {
        const allowed = [
            'image/jpeg', 'image/png', 'image/gif', 'image/webp',
            'application/pdf', 'text/plain', 'application/zip',
            'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        ];
        cb(null, allowed.includes(file.mimetype));
    }
});

// ============ AUTH MIDDLEWARE ============
function auth(req, res, next) {
    const token = req.cookies.token || req.headers.authorization?.split(' ')[1];
    if (!token) return res.status(401).json({ error: 'Belum login' });
    try {
        req.user = jwt.verify(token, process.env.JWT_SECRET);
        next();
    } catch (e) {
        res.status(401).json({ error: 'Token tidak valid' });
    }
}

function adminOnly(req, res, next) {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Akses ditolak' });
    next();
}

// ============ API ROUTES ============

// --- REGISTER ---
app.post('/api/register', async (req, res) => {
    const { email, password, username } = req.body;

    if (!email || !password) return res.status(400).json({ error: 'Email & password wajib' });

    const regOpen = await db.get(`SELECT value FROM settings WHERE key = 'registration_open'`);
    if (regOpen?.value !== 'true') return res.status(403).json({ error: 'Registrasi ditutup' });

    const existing = await db.get('SELECT * FROM users WHERE email = ?', email);
    if (existing) return res.status(400).json({ error: 'Email sudah terdaftar' });

    const hashed = await bcrypt.hash(password, 10);
    await db.run(`
        INSERT INTO users (username, email, password, status)
        VALUES (?, ?, ?, 'pending')
    `, username || null, email, hashed);

    res.json({ message: 'Registrasi berhasil! Tunggu persetujuan admin.' });
});

// --- LOGIN ---
app.post('/api/login', async (req, res) => {
    const { email, password, device_id, device_name, username } = req.body;

    const user = await db.get('SELECT * FROM users WHERE email = ?', email);
    if (!user) return res.status(401).json({ error: 'Email atau password salah' });

    if (user.status === 'pending') return res.status(403).json({ error: 'Akun belum disetujui admin' });
    if (user.status === 'banned') return res.status(403).json({ error: 'Akun diblokir' });

    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(401).json({ error: 'Email atau password salah' });

    // Wajib username di login pertama
    if (!user.username && !username) {
        return res.status(400).json({ 
            require_username: true, 
            message: 'Buat username dulu' 
        });
    }

    // Update username kalo belum ada
    if (!user.username && username) {
        await db.run('UPDATE users SET username = ? WHERE id = ?', username, user.id);
        user.username = username;
    }

    // Cek device limit
    if (device_id) {
        const device = await db.get('SELECT * FROM devices WHERE device_id = ?', device_id);
        if (!device) {
            const count = await db.get('SELECT COUNT(*) as c FROM devices WHERE user_id = ?', user.id);
            const maxDev = user.max_devices || parseInt(process.env.MAX_DEVICES_DEFAULT);
            if (count.c >= maxDev) {
                return res.status(403).json({ 
                    error: `Batas device tercapai (${maxDev}). Hubungi admin.` 
                });
            }
            await db.run('INSERT INTO devices (user_id, device_id, device_name) VALUES (?, ?, ?)', 
                user.id, device_id, device_name || 'Unknown');
        } else {
            await db.run('UPDATE devices SET last_login = CURRENT_TIMESTAMP WHERE device_id = ?', device_id);
        }
    }

    const token = jwt.sign(
        { id: user.id, email: user.email, username: user.username, role: user.role },
        process.env.JWT_SECRET,
        { expiresIn: '7d' }
    );

    res.cookie('token', token, { httpOnly: true, maxAge: 7 * 24 * 60 * 60 * 1000 });
    res.json({
        token,
        user: {
            id: user.id,
            username: user.username,
            email: user.email,
            role: user.role,
            bio: user.bio,
            profile_pic: user.profile_pic
        }
    });
});

// --- LOGOUT ---
app.post('/api/logout', (req, res) => {
    res.clearCookie('token');
    res.json({ message: 'Logout berhasil' });
});

// --- GET ME ---
app.get('/api/me', auth, async (req, res) => {
    const user = await db.get('SELECT id, username, email, role, bio, profile_pic, status, max_devices FROM users WHERE id = ?', req.user.id);
    res.json(user);
});

// --- UPDATE PROFILE ---
app.put('/api/profile', auth, async (req, res) => {
    const { username, bio, password } = req.body;
    const updates = [];
    const params = [];

    if (username) {
        const dup = await db.get('SELECT * FROM users WHERE username = ? AND id != ?', username, req.user.id);
        if (dup) return res.status(400).json({ error: 'Username sudah dipakai' });
        updates.push('username = ?');
        params.push(username);
    }
    if (bio !== undefined) {
        updates.push('bio = ?');
        params.push(bio);
    }
    if (password) {
        const hashed = await bcrypt.hash(password, 10);
        updates.push('password = ?');
        params.push(hashed);
    }

    if (updates.length === 0) return res.status(400).json({ error: 'Tidak ada yang diubah' });

    params.push(req.user.id);
    await db.run(`UPDATE users SET ${updates.join(', ')} WHERE id = ?`, ...params);

    res.json({ message: 'Profil diupdate' });
});

// --- UPLOAD PROFILE PIC ---
app.post('/api/profile/pic', auth, upload.single('profile'), async (req, res) => {
    if (!req.file) return res.status(400).json({ error: 'File tidak ditemukan' });
    const url = `/uploads/profiles/${req.file.filename}`;
    await db.run('UPDATE users SET profile_pic = ? WHERE id = ?', url, req.user.id);
    res.json({ profile_pic: url });
});

// --- GET MESSAGES ---
app.get('/api/messages', auth, async (req, res) => {
    const msgs = await db.all(`
        SELECT m.*, u.profile_pic 
        FROM messages m 
        LEFT JOIN users u ON m.user_id = u.id 
        ORDER BY m.created_at DESC LIMIT 100
    `);
    res.json(msgs.reverse());
});

// --- SEND MESSAGE (dengan file) ---
app.post('/api/messages', auth, upload.single('file'), async (req, res) => {
    const { content } = req.body;
    let file_url = null, file_type = null, file_name = null;

    if (req.file) {
        file_url = `/uploads/chat/${req.file.filename}`;
        file_type = req.file.mimetype;
        file_name = req.file.originalname;
    }

    const result = await db.run(`
        INSERT INTO messages (user_id, username, content, file_url, file_type, file_name)
        VALUES (?, ?, ?, ?, ?, ?)
    `, req.user.id, req.user.username, content || null, file_url, file_type, file_name);

    const msg = await db.get(`
        SELECT m.*, u.profile_pic FROM messages m 
        LEFT JOIN users u ON m.user_id = u.id 
        WHERE m.id = ?
    `, result.lastID);

    io.emit('new_message', msg);
    res.json(msg);
});

// ============ ADMIN ROUTES ============

// --- GET ALL USERS ---
app.get('/api/admin/users', auth, adminOnly, async (req, res) => {
    const users = await db.all('SELECT id, username, email, role, status, max_devices, created_at FROM users ORDER BY created_at DESC');
    res.json(users);
});

// --- APPROVE USER ---
app.put('/api/admin/users/:id/approve', auth, adminOnly, async (req, res) => {
    await db.run('UPDATE users SET status = ? WHERE id = ?', 'approved', req.params.id);
    res.json({ message: 'User disetujui' });
});

// --- BAN USER ---
app.put('/api/admin/users/:id/ban', auth, adminOnly, async (req, res) => {
    await db.run('UPDATE users SET status = ? WHERE id = ?', 'banned', req.params.id);
    res.json({ message: 'User diblokir' });
});

// --- SET MAX DEVICES ---
app.put('/api/admin/users/:id/devices', auth, adminOnly, async (req, res) => {
    const { max_devices } = req.body;
    await db.run('UPDATE users SET max_devices = ? WHERE id = ?', max_devices, req.params.id);
    res.json({ message: 'Batas device diupdate' });
});

// --- DELETE USER ---
app.delete('/api/admin/users/:id', auth, adminOnly, async (req, res) => {
    if (req.params.id == req.user.id) return res.status(400).json({ error: 'Tidak bisa hapus diri sendiri' });
    await db.run('DELETE FROM devices WHERE user_id = ?', req.params.id);
    await db.run('DELETE FROM users WHERE id = ?', req.params.id);
    res.json({ message: 'User dihapus' });
});

// --- SETTINGS ---
app.get('/api/admin/settings', auth, adminOnly, async (req, res) => {
    const settings = await db.all('SELECT * FROM settings');
    res.json(settings);
});

app.put('/api/admin/settings', auth, adminOnly, async (req, res) => {
    const { key, value } = req.body;
    await db.run('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', key, value);
    res.json({ message: 'Setting diupdate' });
});

// ============ SOCKET.IO ============
io.on('connection', (socket) => {
    console.log('🔌 User connected:', socket.id);

    socket.on('disconnect', () => {
        console.log('❌ User disconnected:', socket.id);
    });
});

// ============ START ============
initDB().then(() => {
    server.listen(process.env.PORT || 3000, () => {
        console.log(`🚀 TJKT Hub jalan di http://localhost:${process.env.PORT || 3000}`);
    });
});
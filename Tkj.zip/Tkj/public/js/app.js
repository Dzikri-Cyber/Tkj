// ============================================
// TJKT HUB - DASHBOARD USER LOGIC
// ============================================

// ===== AUTH CHECK =====
const token = localStorage.getItem('token');
if (!token) window.location.href = '/login.html';

const user = JSON.parse(localStorage.getItem('user') || '{}');

// ===== SOCKET =====
const socket = io();

// ===== NAVIGASI =====
document.querySelectorAll('.nav-item[data-page]').forEach(btn => {
    btn.onclick = () => {
        document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
        const page = document.getElementById('page-' + btn.dataset.page);
        if (page) page.classList.add('active');
        document.getElementById('sidebar').classList.remove('open');
    };
});

function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('open');
}

// ===== CHAT =====
let selectedFile = null;

async function loadMessages() {
    try {
        const res = await fetch('/api/messages', {
            headers: { Authorization: 'Bearer ' + token }
        });
        const msgs = await res.json();
        const box = document.getElementById('chatMessages');
        box.innerHTML = '';
        msgs.forEach(renderMessage);
        box.scrollTop = box.scrollHeight;
    } catch (e) {
        console.error('Load messages error:', e);
    }
}

function renderMessage(msg) {
    const box = document.getElementById('chatMessages');
    const div = document.createElement('div');
    div.className = 'msg';

    let fileHtml = '';
    if (msg.file_url) {
        if (msg.file_type && msg.file_type.startsWith('image/')) {
            fileHtml = `<div class="msg-file"><img src="${msg.file_url}" onclick="window.open('${msg.file_url}')" alt="gambar"></div>`;
        } else {
            fileHtml = `<div class="msg-file"><a href="${msg.file_url}" target="_blank">📎 ${msg.file_name || 'Download'}</a></div>`;
        }
    }

    const avatarContent = msg.profile_pic
        ? `<img src="${msg.profile_pic}" alt="avatar">`
        : (msg.username ? msg.username[0].toUpperCase() : '?');

    div.innerHTML = `
        <div class="msg-avatar">${avatarContent}</div>
        <div class="msg-body">
            <div class="msg-name">${msg.username || 'User'}</div>
            ${msg.content ? `<div class="msg-text">${escapeHtml(msg.content)}</div>` : ''}
            ${fileHtml}
            <div class="msg-time">${formatTime(msg.created_at)}</div>
        </div>
    `;
    box.appendChild(div);
    box.scrollTop = box.scrollHeight;
}

function escapeHtml(s) {
    const d = document.createElement('div');
    d.textContent = s;
    return d.innerHTML;
}

function formatTime(ts) {
    try {
        const d = new Date(ts);
        return d.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
    } catch (e) {
        return '';
    }
}

function fileSelected() {
    const file = document.getElementById('fileInput').files[0];
    selectedFile = file;
    document.getElementById('filePreview').textContent = file ? '📎 ' + file.name : '';
}

async function sendMessage(e) {
    e.preventDefault();
    const content = document.getElementById('msgInput').value.trim();
    if (!content && !selectedFile) return;

    const formData = new FormData();
    if (content) formData.append('content', content);
    if (selectedFile) formData.append('file', selectedFile);

    document.getElementById('msgInput').value = '';
    document.getElementById('fileInput').value = '';
    document.getElementById('filePreview').textContent = '';
    selectedFile = null;

    try {
        await fetch('/api/messages', {
            method: 'POST',
            headers: { Authorization: 'Bearer ' + token },
            body: formData
        });
    } catch (e) {
        console.error('Send message error:', e);
    }
}

socket.on('new_message', renderMessage);

// ===== PROFILE =====
async function loadProfile() {
    try {
        const res = await fetch('/api/me', {
            headers: { Authorization: 'Bearer ' + token }
        });
        const u = await res.json();

        document.getElementById('profileName').textContent = u.username || 'Belum ada username';
        document.getElementById('profileEmail').textContent = u.email;
        document.getElementById('editUsername').value = u.username || '';
        document.getElementById('editBio').value = u.bio || '';

        const pic = document.getElementById('profilePic');
        if (u.profile_pic) {
            pic.innerHTML = `<img src="${u.profile_pic}" alt="avatar">`;
        } else {
            pic.textContent = (u.username ? u.username[0] : 'U').toUpperCase();
        }
    } catch (e) {
        console.error('Load profile error:', e);
    }
}

async function saveProfile() {
    const username = document.getElementById('editUsername').value.trim();
    const bio = document.getElementById('editBio').value.trim();
    const msg = document.getElementById('profileMsg');

    msg.textContent = 'Menyimpan...';

    try {
        const res = await fetch('/api/profile', {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                Authorization: 'Bearer ' + token
            },
            body: JSON.stringify({ username, bio })
        });
        const data = await res.json();
        msg.textContent = data.message || data.error;

        // Update local user
        user.username = username;
        localStorage.setItem('user', JSON.stringify(user));
    } catch (e) {
        msg.textContent = 'Error: ' + e.message;
    }
}

async function uploadProfilePic(input) {
    const file = input.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('profile', file);

    try {
        const res = await fetch('/api/profile/pic', {
            method: 'POST',
            headers: { Authorization: 'Bearer ' + token },
            body: formData
        });
        const data = await res.json();
        if (data.profile_pic) {
            const pic = document.getElementById('profilePic');
            pic.innerHTML = `<img src="${data.profile_pic}" alt="avatar">`;
            document.getElementById('profileMsg').textContent = '✅ Foto profil diupdate';
        }
    } catch (e) {
        document.getElementById('profileMsg').textContent = 'Error: ' + e.message;
    }
}

// ===== LOGOUT =====
async function logout() {
    if (!confirm('Yakin mau logout?')) return;
    try {
        await fetch('/api/logout', { method: 'POST' });
    } catch (e) {}
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = '/login.html';
}

// ===== THEME =====
function toggleTheme() {
    const d = document.documentElement;
    const currentBg = getComputedStyle(d).getPropertyValue('--bg').trim();
    const isDark = currentBg === '#0b0b0b';
    d.dataset.theme = isDark ? 'light' : 'dark';
    localStorage.setItem('theme', d.dataset.theme);
}

if (localStorage.getItem('theme')) {
    document.documentElement.dataset.theme = localStorage.getItem('theme');
}

// ===== INIT =====
loadMessages();
loadProfile();
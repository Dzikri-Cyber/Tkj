// ============================================
// TJKT HUB - ADMIN PANEL LOGIC
// ============================================

const token = localStorage.getItem('token');
if (!token) window.location.href = '/login.html';

const user = JSON.parse(localStorage.getItem('user') || '{}');
if (user.role !== 'admin') {
    alert('Akses ditolak! Hanya admin yang bisa masuk.');
    window.location.href = '/index.html';
}

// ===== NAVIGASI =====
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('open');
}

document.querySelectorAll('.nav-item[data-page]').forEach(btn => {
    btn.onclick = () => {
        document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
        const page = document.getElementById('page-' + btn.dataset.page);
        if (page) page.classList.add('active');
        document.getElementById('sidebar').classList.remove('open');
    };
});

// ===== USERS =====
async function loadUsers() {
    try {
        const res = await fetch('/api/admin/users', {
            headers: { Authorization: 'Bearer ' + token }
        });
        const users = await res.json();
        const tbody = document.getElementById('userTable');

        if (!users.length) {
            tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:var(--mut)">Belum ada user</td></tr>';
            return;
        }

        tbody.innerHTML = users.map(u => `
            <tr>
                <td><strong>${u.username || '-'}</strong></td>
                <td>${u.email}</td>
                <td>${u.role}</td>
                <td><span class="badge ${u.status === 'approved' ? 'green' : u.status === 'banned' ? 'red' : 'yellow'}">${u.status}</span></td>
                <td>${u.max_devices}</td>
                <td>
                    ${u.status === 'pending' ? `<button onclick="approveUser(${u.id})" style="padding:5px 10px;font-size:12px">✅</button>` : ''}
                    ${u.status !== 'banned' ? `<button onclick="banUser(${u.id})" style="padding:5px 10px;font-size:12px;color:#ef4444">🚫</button>` : ''}
                    <button onclick="changeDeviceLimit(${u.id}, ${u.max_devices})" style="padding:5px 10px;font-size:12px">📱</button>
                    <button onclick="deleteUser(${u.id})" style="padding:5px 10px;font-size:12px;color:#ef4444">🗑️</button>
                </td>
            </tr>
        `).join('');
    } catch (e) {
        console.error('Load users error:', e);
    }
}

async function approveUser(id) {
    if (!confirm('Setujui user ini?')) return;
    await fetch(`/api/admin/users/${id}/approve`, {
        method: 'PUT',
        headers: { Authorization: 'Bearer ' + token }
    });
    loadUsers();
}

async function banUser(id) {
    if (!confirm('Ban user ini?')) return;
    await fetch(`/api/admin/users/${id}/ban`, {
        method: 'PUT',
        headers: { Authorization: 'Bearer ' + token }
    });
    loadUsers();
}

async function changeDeviceLimit(id, current) {
    const val = prompt('Max device untuk user ini:', current);
    if (!val || isNaN(val)) return;
    await fetch(`/api/admin/users/${id}/devices`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + token
        },
        body: JSON.stringify({ max_devices: parseInt(val) })
    });
    loadUsers();
}

async function deleteUser(id) {
    if (!confirm('Yakin hapus user ini? Semua data akan hilang!')) return;
    await fetch(`/api/admin/users/${id}`, {
        method: 'DELETE',
        headers: { Authorization: 'Bearer ' + token }
    });
    loadUsers();
}

// ===== SETTINGS =====
async function loadSettings() {
    try {
        const res = await fetch('/api/admin/settings', {
            headers: { Authorization: 'Bearer ' + token }
        });
        const settings = await res.json();

        const reg = settings.find(s => s.key === 'registration_open');
        const maxDev = settings.find(s => s.key === 'max_devices_default');

        if (reg) document.getElementById('regOpen').value = reg.value;
        if (maxDev) document.getElementById('maxDev').value = maxDev.value;
    } catch (e) {
        console.error('Load settings error:', e);
    }
}

async function saveSetting(key, value) {
    try {
        await fetch('/api/admin/settings', {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                Authorization: 'Bearer ' + token
            },
            body: JSON.stringify({ key, value })
        });
        console.log('✅ Setting saved:', key, '=', value);
    } catch (e) {
        console.error('Save setting error:', e);
    }
}

// ===== LOGOUT =====
async function logout() {
    if (!confirm('Yakin mau logout?')) return;
    try {
        await fetch('/api/logout', { method: 'POST' });
    } catch (e) {}
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = '/login.html';
}

// ===== THEME =====
function toggleTheme() {
    const d = document.documentElement;
    const currentBg = getComputedStyle(d).getPropertyValue('--bg').trim();
    const isDark = currentBg === '#0b0b0b';
    d.dataset.theme = isDark ? 'light' : 'dark';
    localStorage.setItem('theme', d.dataset.theme);
}

if (localStorage.getItem('theme')) {
    document.documentElement.dataset.theme = localStorage.getItem('theme');
}

// ===== INIT =====
loadUsers();
loadSettings();